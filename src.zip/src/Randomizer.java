import java.awt.Color;
import java.awt.Graphics;


public class Randomizer {
	
	public void getRandomColor(int x, Graphics grph) {
		
		switch(x) {
			case 0:
				grph.setColor(Color.BLACK); 
				break;
				
			case 1:
				grph.setColor(Color.RED);
				break;
				
			case 2:
				grph.setColor(Color.GREEN);
				break;
		}
				
		
	}

}
