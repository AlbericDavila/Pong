//
// Class used to create the Menu (optional)
//
public class Launcher {
	public static void main(String[] args) {
		new Menu();
	}
}
